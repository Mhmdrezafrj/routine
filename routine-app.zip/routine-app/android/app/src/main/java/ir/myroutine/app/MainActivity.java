package ir.myroutine.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    static final String CH = "routine_reminders";
    WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel(this);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F7F4FF"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "یادآورها", NotificationManager.IMPORTANCE_HIGH);
            ((NotificationManager) c.getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.__back&&window.__back()", v -> { if (!"true".equals(v)) finish(); });
    }

    class Bridge {
        @JavascriptInterface public void notify(String title, String body) { AlarmReceiver.show(MainActivity.this, title, body, (int) System.nanoTime()); }

        @JavascriptInterface public void saveFile(String name, String text, String mime) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
            } catch (Exception e) { throw new RuntimeException(e); }
        }

        /** لیست یادآورهای ۳ روز آینده را دریافت و با AlarmManager زمان‌بندی می‌کند (حتی با برنامه بسته). */
        @JavascriptInterface public void schedule(String json) {
            try {
                AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
                SharedPreferences sp = getSharedPreferences("alarms", MODE_PRIVATE);
                for (String k : sp.getStringSet("codes", new HashSet<>())) am.cancel(pi(Integer.parseInt(k), null, null));
                Set<String> codes = new HashSet<>();
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    int code = o.getString("id").hashCode();
                    codes.add(String.valueOf(code));
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, o.getLong("ts"), pi(code, o.getString("title"), o.getString("body")));
                }
                sp.edit().putStringSet("codes", codes).apply();
            } catch (Exception ignored) {}
        }

        PendingIntent pi(int code, String t, String b) {
            Intent i = new Intent(MainActivity.this, AlarmReceiver.class).putExtra("t", t).putExtra("b", b);
            return PendingIntent.getBroadcast(MainActivity.this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }
    }
}
